public class Aufgabe1 {

    public static void main (String args[])
    {
        System.out.println("Hello World");
        System.out.println("Kilian Bauer");
        System.out.println("Tabulator beobachtet");
    }
}
