package aufgabe1_package2;

public class Package2 {

    public static void main (String arg[])
    {
        System.out.println("FH Kufstein Tirol");
    }
}
